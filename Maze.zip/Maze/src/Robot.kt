import java.util.*
import kotlin.collections.*
class Robot(var name:String) {

    fun greeting(){
        println("Hello! my name is $name, I am your Personal Assistant ")
        println("I will do all your work so you can save your time")
        println("Just give me Inputs I will do your all work without any fees ;-)")
    }


    var time:String?=null
    var day:String?=null
    fun ringMyAlarm(dayNotRing:String, time:String)
    {

        println("I will ring all the days except these days: $dayNotRing")
        println("Your alarm is Set ")
        println("Your alarm will ring on $time")
    }
    var coffeeColor:String?=null
    var sugerQnt:Int?=null
    fun makeMyCoffee(coffeeColor:String,sugerQnt:Int){

        if(coffeeColor=="black"){
            println("I will make your  $coffeeColor coffee on time don't worry! ")
        }
        else{
            println("I will make your $coffeeColor coffee on time don't worry!")
        }

        println("Your $coffeeColor coffee is ready with $sugerQnt tablespoon. ")
    }


    var temp:Double?=null

    fun heatTheWater(temp:Double, day:String) {

        println("You set the temperature on $temp F on these days ")
        if (day == "everyday" || day == "Everyday") {
            var arr = arrayOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
            for (i in arr)
            {
                println(i)
            }
        }
    }
    var noOfSub:Int?=null
    var subjectList:Array<String>?=null
    var i:Int=1
    fun packYourBag(noOfSub:Int, subjectList: Array<String>){

       var arr:Array<String?> = arrayOf("Monday","Tuesday","wednesday","Thursday","Friday","Saturday")
        for(i in arr){
            println("Subjects for day $i are ")
            for(j in subjectList){
                println(j)
            }
        }
    }

    var foodItems:String?=null
    fun cookBreakfast(){
        var newListOfFoodItemsBreakfast= mutableListOf("Omlet","bread","milk and bread","Parathas")

        var newListOfFoodItemsDinner= mutableListOf("paw bhaji","potato vegitable","idle sambhar","chapati ,dal and rice")

        println("Your Breakfast is ready ${newListOfFoodItemsBreakfast.random()}")
        println("your dinner will be  ready on time and your today's meal is: ${newListOfFoodItemsDinner.random()} ")
    }

    var clothes:String?=null
    fun ironMyClothes(clothes:String)
    {
        println("your Iron is finished on :  $clothes ")
    }

}



fun main(){

    val roboFunction=Robot("Maze")

    roboFunction.greeting()
    roboFunction.ringMyAlarm("Sunday","09:30 Am")
    roboFunction.makeMyCoffee("white",2)
    roboFunction.heatTheWater(28.5,"everyday")
    var newarrayOfSubjects= arrayOf("Kotlin","Android Studios","Java")
    roboFunction.packYourBag(3,newarrayOfSubjects)
    roboFunction.cookBreakfast()
    roboFunction.ironMyClothes("college dress")

}